package com.jdbc_practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class StudentJDBC1 {

    static String URL = "jdbc:mysql://localhost:3306/student";
    static String USER = "root";
    static String PASSWORD = "root";

    public static void main(String[] args) {

        Connection con = null;
        Scanner sc = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(URL, USER, PASSWORD);

            System.out.println("Database connected successfully!");

            sc = new Scanner(System.in);

            int choice;

            do {

                System.out.println("       STUDENT MANAGEMENT SYSTEM");
                System.out.println("-------------------------------------");
                System.out.println("1. Add Student");
                System.out.println("2. View All Students");
                System.out.println("3. Search Student by ID");
                System.out.println("4. Search Student by Name");
                System.out.println("5. Search Student by Email");
                System.out.println("6. Update Student");
                System.out.println("7. Delete Student");
                System.out.println("8. Transaction Management");
                System.out.println("9. Exit");
                System.out.println("-------------------------------------");
                
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                case 1:
                    addStudent(sc, con);
                    break;

                case 2:
                    viewAllStudents(con);
                    break;

                case 3:
                    searchStudentById(sc, con);
                    break;

                case 4:
                    searchStudentByName(sc, con);
                    break;

                case 5:
                    searchStudentByEmail(sc, con);
                    break;

                case 6:
                    updateStudent(sc, con);
                    break;

                case 7:
                    deleteStudent(sc, con);
                    break;

                case 8:
                    transactionManagement(sc, con);
                    break;

                case 9:
                    System.out.println("Program ended.");
                    break;

                default:
                    System.out.println("Invalid choice!");
                }

            } while (choice != 9);

        } catch (ClassNotFoundException e) {

            System.out.println("JDBC Driver not found.");
            e.printStackTrace();

        } catch (SQLException e) {

            System.out.println("Database error.");
            e.printStackTrace();
        }

        } 
        
    // 1. ADD STUDENT
    public static void addStudent(Scanner sc,Connection con) throws SQLException {

        PreparedStatement psInsert = null;

            System.out.println("\n---------- ADD STUDENT ----------");
            String sql =  "INSERT INTO student (name, email) VALUES (?, ?)";

            psInsert = con.prepareStatement(sql);

            System.out.print("Enter student name: ");
            String name = sc.nextLine();

            System.out.print("Enter student email: ");
            String email = sc.nextLine();

            psInsert.setString(1, name);
            psInsert.setString(2, email);

            int rows = psInsert.executeUpdate();

            if (rows > 0) {

                System.out.println("Student inserted successfully!");

            } else {

                System.out.println("Student was not inserted.");
            }
            psInsert.close();

    }
    
    // 2. VIEW ALL STUDENTS
    
    public static void viewAllStudents(Connection con) throws SQLException {

        Statement st = null;
        ResultSet rs = null;


            System.out.println("\n---------- ALL STUDENTS ----------");

            String sql = "SELECT * FROM student";

            st = con.createStatement();

            rs = st.executeQuery(sql);

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println("ID    : "+ rs.getInt("id"));

                System.out.println("Name  : "+ rs.getString("name"));

                System.out.println("Email : "+ rs.getString("email"));

                System.out.println("--------------------------------");
            }

            if (!found) {

                System.out.println("No students found.");
            }

            if (rs != null) {
                rs.close();
            }

            if (st != null) {
                st.close();
            }

        
    }
    // 3. SEARCH STUDENT BY ID
    
    public static void searchStudentById(Scanner sc,Connection con) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;


            System.out.println("\n---------- SEARCH BY ID ----------");

            System.out.print("Enter student ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            String sql = "SELECT * FROM student WHERE id = ?";

            ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            rs = ps.executeQuery();

            if (rs.next()) {

                System.out.println("\nStudent found!");

                System.out.println("ID    : "
                        + rs.getInt("id"));

                System.out.println("Name  : "
                        + rs.getString("name"));

                System.out.println("Email : "
                        + rs.getString("email"));

            } else {

                System.out.println("Student with ID " + id + " not found.");
            }

            if (rs != null) {
                rs.close();
            }

            if (ps != null) {
                ps.close();
            }

        
    }
    // 4. SEARCH STUDENT BY NAME
    
    public static void searchStudentByName(Scanner sc,Connection con) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        
        	System.out.println(
                    "\n---------- SEARCH BY NAME ----------");

            System.out.print("Enter student name: ");
            String name = sc.nextLine();

            String sql = "SELECT * FROM student WHERE name = ?";

            ps = con.prepareStatement(sql);

            ps.setString(1, name);

            rs = ps.executeQuery();

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println("\nStudent found!");

                System.out.println("ID    : "
                        + rs.getInt("id"));

                System.out.println("Name  : "
                        + rs.getString("name"));

                System.out.println("Email : "
                        + rs.getString("email"));

                System.out.println("--------------------------------");
            }

            if (!found) {

                System.out.println("Student with name '" + name+ "' not found.");
            }

            if (rs != null) {
                rs.close();
            }

            if (ps != null) {
                ps.close();
            }

    } 
    // 5. SEARCH STUDENT BY EMAIL
    
    public static void searchStudentByEmail(
            Scanner sc,
            Connection con) {

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            System.out.println(
                    "\n---------- SEARCH BY EMAIL ----------");

            System.out.print("Enter student email: ");
            String email = sc.nextLine();

            String sql ="SELECT * FROM student WHERE email = ?";

            ps = con.prepareStatement(sql);

            ps.setString(1, email);

            rs = ps.executeQuery();

            if (rs.next()) {

                System.out.println("\nStudent found!");

                System.out.println("ID    : "
                        + rs.getInt("id"));

                System.out.println("Name  : "
                        + rs.getString("name"));

                System.out.println("Email : "
                        + rs.getString("email"));

            } else {

                System.out.println(
                        "Student with email '" + email
                                + "' not found.");
            }

            if (rs != null) {
                rs.close();
            }

            if (ps != null) {
                ps.close();
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    
    // 6. UPDATE STUDENT
    
    public static void updateStudent(
            Scanner sc,
            Connection con) {

        PreparedStatement psUpdate = null;

        try {

            System.out.println(
                    "\n---------- UPDATE STUDENT ----------");

            // PreparedStatement for UPDATE
            psUpdate = con.prepareStatement(
                    "UPDATE student SET name = ?, email = ? WHERE id = ?");

            System.out.print("Enter student ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter new student name: ");
            String name = sc.nextLine();

            System.out.print("Enter new student email: ");
            String email = sc.nextLine();

            psUpdate.setString(1, name);
            psUpdate.setString(2, email);
            psUpdate.setInt(3, id);

            int rows = psUpdate.executeUpdate();

            if (rows > 0) {

                System.out.println(
                        "Student updated successfully!");

            } else {

                System.out.println(
                        "Student ID not found.");

                System.out.println(
                        "No rows were updated.");
            }

            psUpdate.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    
    // 7. DELETE STUDENT
    
    public static void deleteStudent(
            Scanner sc,
            Connection con) {

        PreparedStatement psDelete = null;

        try {

            System.out.println(
                    "\n---------- DELETE STUDENT ----------");

            // PreparedStatement for DELETE
            psDelete = con.prepareStatement(
                    "DELETE FROM student WHERE id = ?");

            System.out.print("Enter student ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            psDelete.setInt(1, id);

            int rows = psDelete.executeUpdate();

            if (rows > 0) {

                System.out.println(
                        "Student deleted successfully!");

            } else {

                System.out.println(
                        "Student ID not found.");

                System.out.println(
                        "No rows were deleted.");
            }

            psDelete.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    // 8. TRANSACTION MANAGEMENT
    
    public static void transactionManagement(
            Scanner sc,
            Connection con) {

        PreparedStatement psInsert = null;
        PreparedStatement psUpdate = null;
        PreparedStatement psDelete = null;

        try {

            System.out.println("\n---------- TRANSACTION MANAGEMENT ----------");

            psInsert = con.prepareStatement("INSERT INTO student (name, email) VALUES (?, ?)");

            psUpdate = con.prepareStatement("UPDATE student SET name = ?, email = ? WHERE id = ?");

            psDelete = con.prepareStatement("DELETE FROM student WHERE id = ?");

            con.setAutoCommit(false);

            System.out.print("Enter student name: ");
            String name = sc.nextLine();

            System.out.print("Enter student email: ");
            String email = sc.nextLine();

            psInsert.setString(1, name);
            psInsert.setString(2, email);

            int insertRows =
                    psInsert.executeUpdate();

            if (insertRows > 0) {

                System.out.println("Student inserted successfully.");

            } else {

                System.out.println("Student was not inserted.");
            }
            
            System.out.print("\nEnter student ID to update: ");

            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter new student name: ");
            String newName = sc.nextLine();

            System.out.print("Enter new student email: ");
            String newEmail = sc.nextLine();

            psUpdate.setString(1, newName);
            psUpdate.setString(2, newEmail);
            psUpdate.setInt(3, id);

            int updateRows =
                    psUpdate.executeUpdate();

            if (updateRows > 0) {

                System.out.println("Student updated successfully.");

            } else {

                System.out.println("Student ID not found.");

                System.out.println("No rows were updated.");
            }
            // DELETE
            
            System.out.print("\nEnter student ID to delete: ");

            int deleteId = sc.nextInt();
            sc.nextLine();

            psDelete.setInt(1, deleteId);

            int deleteRows =
                    psDelete.executeUpdate();

            if (deleteRows > 0) {

                System.out.println("Student deleted successfully.");

            } else {

                System.out.println("Student ID not found.");

                System.out.println("No rows were deleted.");
            }
            // COMMIT / ROLLBACK
            
            System.out.println("\n1. Commit");
            System.out.println("2. Rollback");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 1) {

                con.commit();

                System.out.println("Transaction committed successfully!");

            } else if (choice == 2) {

                con.rollback();

                System.out.println("Transaction rolled back successfully!");

            } else {

                con.rollback();

                System.out.println("Invalid choice.");

                System.out.println("Transaction rolled back.");
            }

            // Restore Auto Commit
            con.setAutoCommit(true);

            psInsert.close();
            psUpdate.close();
            psDelete.close();

        } catch (SQLException e) {

            try {

                if (con != null) {

                    con.rollback();

                    System.out.println("Transaction rolled back.");
                }

            } catch (SQLException rollbackException) {

                rollbackException.printStackTrace();
            }

            e.printStackTrace();
        }
    
    finally {

        try {

            if (sc != null) {
                sc.close();
            }

            if (con != null) {
                con.close();
            }

            System.out.println("Resources closed successfully.");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
   }
}