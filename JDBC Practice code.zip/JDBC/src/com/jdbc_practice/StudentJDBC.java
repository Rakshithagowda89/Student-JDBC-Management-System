package com.jdbc_practice;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

public class StudentJDBC {
    public static void main(String[] args) {
    	String URL = "jdbc:mysql://localhost:3306/student";

        String USER = "root";

        String PASSWORD = "root";

        try {
        	
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	
            Connection con = DriverManager.getConnection(URL,USER,PASSWORD);
            
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter student name:");
            String name = sc.nextLine();

            System.out.println("Enter student email:");
            String email = sc.nextLine();

            
            String sql = "INSERT INTO student (name, email) VALUES (?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Student details inserted successfully!");
            }

            ps.close();
            con.close();
            sc.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}